# Appoo (una app sobre la caca)

---

## integrantes

Francisco Astete

Ricardo Castillo

Javier Espinoza

Patricio Garrido

María-Fernanda Villalobos

---

## info

### Permisos

Hemos creador 3 tipos de permisos

- editor: _todo, excepto admin y auth_.

- content_creator: _permisos para escribir contenido en las páginas_.

- visit: _solo permisos para ver_.

### Instrucciones para levantar el proyecto

- En el archivo **requirements.txt** estan las librerias necesarias para levantar el proyecto

- El entorno virtual usado es **Pipenv**

- Las contraseñas de prueba para cada usuario estan **README-pass-test.txt**.
