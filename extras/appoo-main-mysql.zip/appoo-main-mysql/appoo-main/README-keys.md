# keys dev

## superuser

user: appoo
email: hola@appoo.cl
pass: Caca1000.

## users

user: patricio
email: patricio@appoo.cl
pass: 1Caquita.

user: javier
email: javier@appoo.cl
pass: 1Caquita.

user: ricardo
email: ricardo@appoo.cl
pass: 1Caquita.

user: marifer
email: marifer@appoo.cl
pass: 1Caquita.

user: francisco
email: francisco@appoo.cl
pass: 1Caquita.
